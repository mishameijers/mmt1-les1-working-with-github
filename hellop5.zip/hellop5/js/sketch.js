
let ellipseWidth = 50;
let ellipseHeight = 50;

function setup() {
  createCanvas(800,300);
  background("pink");
}

function draw() {
  let ellipseX = mouseX;
  let ellipseY = mouseY;

  ellipse(ellipseX, ellipseY, ellipseWidth, ellipseHeight);
}